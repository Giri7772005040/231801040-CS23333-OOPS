import { useState } from "react";
import { PersonForm } from "./components/PersonForm";
import { PersonList } from "./components/PersonList";
import { SearchBar } from "./components/SearchBar";
import { Button } from "./components/ui/button";
import { generateId } from "./lib/utils";
import type { Person } from "./types/person";

export default function App() {
  const [people, setPeople] = useState<Person[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const handleSubmit = (data: Omit<Person, "id">) => {
    if (editingPerson) {
      setPeople((prev) =>
        prev.map((p) =>
          p.id === editingPerson.id ? { ...data, id: p.id } : p
        )
      );
      setEditingPerson(null);
    } else {
      setPeople((prev) => [...prev, { ...data, id: generateId() }]);
    }
    setIsFormOpen(false);
  };

  const handleEdit = (person: Person) => {
    setEditingPerson(person);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    setPeople((prev) => prev.filter((p) => p.id !== id));
  };

  const filteredPeople = people.filter(
    (person) =>
      person.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Personal Information Tracker</h1>
          <Button onClick={() => setIsFormOpen(true)}>Add Person</Button>
        </div>

        <SearchBar onSearch={setSearchQuery} />

        {isFormOpen && (
          <div className="mb-8 p-6 bg-white rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">
              {editingPerson ? "Edit Person" : "Add New Person"}
            </h2>
            <PersonForm
              onSubmit={handleSubmit}
              initialData={editingPerson || undefined}
            />
          </div>
        )}

        <PersonList
          people={filteredPeople}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>
    </div>
  );
}